package demo5;

public interface ReportGenerator {
	public void generate();
}
