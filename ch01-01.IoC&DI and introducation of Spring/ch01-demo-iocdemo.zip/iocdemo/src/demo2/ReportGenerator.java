package demo2;

public interface ReportGenerator {
	public void generate();
}
