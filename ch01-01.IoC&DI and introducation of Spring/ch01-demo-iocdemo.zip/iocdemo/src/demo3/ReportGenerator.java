package demo3;

public interface ReportGenerator {
	public void generate();
}
