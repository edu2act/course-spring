package demo3;

public class PdfReportGenerator implements ReportGenerator {
	public void generate(){
		System.out.println("生成Pdf格式的报表！");
	}
}
