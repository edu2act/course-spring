package demo4;

public interface ReportGenerator {
	public void generate();
}
