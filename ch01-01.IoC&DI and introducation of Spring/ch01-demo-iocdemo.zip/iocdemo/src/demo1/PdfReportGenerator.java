package demo1;

public class PdfReportGenerator {
	public void generate(){
		System.out.println("生成Pdf格式的报表！");
	}
}
