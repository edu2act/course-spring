package demo1;

public class HtmlReportGenerator {
	public void generate(){
		System.out.println("生成Html格式的报表！");
	}
}
