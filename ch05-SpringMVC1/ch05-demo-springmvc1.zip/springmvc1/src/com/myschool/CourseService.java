package com.myschool;

public class CourseService {
	
	public boolean checkCourse(String courseName){
		return true;
	}

}
