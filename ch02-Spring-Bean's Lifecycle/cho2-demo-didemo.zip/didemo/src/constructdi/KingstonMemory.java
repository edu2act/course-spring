package constructdi;

public class KingstonMemory {

}
