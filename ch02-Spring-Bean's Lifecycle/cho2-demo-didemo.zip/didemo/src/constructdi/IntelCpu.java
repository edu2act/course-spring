package constructdi;

public class IntelCpu {
	
}
