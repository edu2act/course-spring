package setterdi;

public class KingstonMemory {

}
