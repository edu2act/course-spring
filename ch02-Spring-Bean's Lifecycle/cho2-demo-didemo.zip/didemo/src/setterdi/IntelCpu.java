package setterdi;

public class IntelCpu {
	
}
