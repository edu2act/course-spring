package setterdi;

public class Computer {
	private IntelCpu intelCpu;
	private KingstonMemory kingstonMemory;
	
	public void setIntelCpu(IntelCpu intelCpu) {
		this.intelCpu = intelCpu;
	}
	public void setKingstonMemory(KingstonMemory kingstonMemory) {
		this.kingstonMemory = kingstonMemory;
	}

}
