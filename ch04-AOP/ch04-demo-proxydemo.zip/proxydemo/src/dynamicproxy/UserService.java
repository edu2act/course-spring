package dynamicproxy;

public interface UserService {
	public boolean login(String name, String password);
}
